Font License Information

    * These fonts are free for personal and commercial use
    * These fonts may not be modified
    * These fonts may not be distributed -not online nor on any media- without my permission
    * These fonts may not be sold
    * These fonts sre the intellecual property of Derek Clark
    * defaulterror (Derek Clark) is not liable for any damage resulting from the use of these fonts

Please feel free to send me any comments you have regarding the fonts, especially if you use them in your work.
I would love to see where these fonts end up!

d.rockafella@gmail.com

http://defaulterror.za.net